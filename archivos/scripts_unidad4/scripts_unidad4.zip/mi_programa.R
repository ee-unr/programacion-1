a <- "¡Hola, Mundo!"
b <- 3
d <- 5
cat("==========================================\n")
cat("                 RESULTADOS               \n")
cat("==========================================\n\n")
cat("El valor de b es ", b, ", mientras que d vale ", d, ".\n\n", sep = "")
cat("La suma entre ellos es igual a ", b + d, ".\n\n", sep = "")
cat("Este es un saludo:", a)
